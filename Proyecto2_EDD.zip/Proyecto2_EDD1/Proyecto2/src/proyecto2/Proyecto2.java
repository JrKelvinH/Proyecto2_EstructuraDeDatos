package proyecto2;


public class Proyecto2 {
    private static HashTable hashTable = new HashTable();
    private static AVLTree avlAutores = new AVLTree();
    private static AVLTree avlPalabrasClave = new AVLTree();

    public static void precargarDatos() {
        
    }
    
    public static void main(String[] args) {

    }
}
