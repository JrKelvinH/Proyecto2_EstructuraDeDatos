INTEGRANTES:
Kelvin Hurtado C.I: 26794618  
Luis Bravo C.I: 31.852.011  
Carlos Padron C.I: 31.785.756

Enlace al GitHub: https://github.com/JrKelvinH/Proyecto2_EstructuraDeDatos

Este proyecto es un analizador de resumenes científicos, el sistema viene precargado con 3 resumenes pero se pueden
añadir más usando el botón archivo y agregar, una vez hecho esto puedes seleccionarlo y analizarlo para que el sistema identifique el titulo, autor y palabras clave.