/**
 * Proyecto2: Clase del proyecto. Comentario breve escrito por estudiantes.
 * Aquí se maneja la lógica principal relacionada con proyecto2.
 * Autores: Carlos Padrón, Kelvin Hurtado, Luis Bravo
 */
package proyecto2;


public class Proyecto2 {
    private static HashTable hashTable = new HashTable();
    private static AVLTree avlAutores = new AVLTree();
    private static AVLTree avlPalabrasClave = new AVLTree();

    public static void precargarDatos() {
        
    }
    
    public static void main(String[] args) {

    }
}
